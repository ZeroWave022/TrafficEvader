"""Sound manager"""

import pygame
from src.utils import asset_path


class Sounds:
    """Class storing game sounds"""

    def __init__(self) -> None:
        self.coin = pygame.mixer.Sound(asset_path("sounds/coin.ogg"))
        self.explosion = pygame.mixer.Sound(asset_path("sounds/explosion.ogg"))
        self.click = pygame.mixer.Sound(asset_path("sounds/menu_click.ogg"))
        self.click_deny = pygame.mixer.Sound(asset_path("sounds/menu_deny.ogg"))

        self.coin.set_volume(0.3)
        self.explosion.set_volume(0.3)
        self.click.set_volume(0.5)
        self.click_deny.set_volume(0.5)
